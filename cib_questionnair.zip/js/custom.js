/*Alternate Address Change*/
$('#insert-btn1').click(function() {   
    $('.form-control-1:last').after('<div class="form-control-1"><hr/> <h4>Mailing/Alternate Address</h4><div class="row"><div class="col-sm-4"><div class="form-group"> <label>Account Type</label> <select class="form-control"><option>--Select Account Type--</option><option>--Account Type--</option> </select></div></div><div class="col-sm-4"><div class="form-group"> <label>Account Number</label> <input type="text" class="form-control"></div></div><div class="col-sm-4"><div class="form-group"> <label>Expiration Behavior</label> <select class="form-control"><option>--select Expiration Behavior--</option><option>--select Expiration Behavior--</option> </select></div></div></div><div class="row"><div class="col-sm-4"><div class="form-group"> <label>Address Type</label> <select class="form-control"><option>--Select Address Type--</option><option>--Address Type--</option> </select></div></div><div class="col-sm-4"><div class="form-group"> <label>Start Date</label> <input type="date" class="form-control"></div></div><div class="col-sm-4"><div class="form-group"> <label>End Date</label> <input type="date" class="form-control"></div></div></div><h4>Mailing Address</h4><div class="row"><div class="col-sm-4"><div class="form-group"> <label>Address Line1</label> <input type="text" class="form-control"></div><div class="form-group"> <label>Address Line2</label> <input type="text" class="form-control"></div></div><div class="col-sm-4"><div class="form-group"> <label>State/Parish</label> <input type="text" class="form-control"></div><div class="form-group"> <label>City</label> <input type="text" class="form-control"></div></div><div class="col-sm-4"><div class="form-group"> <label>Zip/Postal Code</label> <input type="text" class="form-control"></div><div class="form-group"> <label>Country</label> <select class="form-control"><option>--Select Country--</option><option>--Select Country--</option> </select></div></div></div>'+
    
    '<button type="button" class="remove-btn1"><i class="fas fa-minus"></i> Remove  Item</button></div>');
});
$('.panel-body').on('click','.remove-btn1',function() {
 	$(this).parent().remove();
});




/*Email Information*/
$('#insert-btn2').click(function() {   
    $('.form-control-2:last').after('<div class="form-area row" id="form-control-2">'+
    '<div class="col-md-10"><input class="form-control col-sm-12" type="email" placeholder="Enter your Email Address"></div>'+    
    '<button type="button" id="remove-btn1" class="remove_btn"><i class="fas fa-minus"></i></button></div>');
});

$('.panel-body').on('click','#remove-btn1',function() {
    $(this).parent().remove();
});

/*Email Information*/

/*hHome Telephone Number*/

$('#insert-btn3').click(function() {   
    $('.form-control-3:last').after('<div class="row form-area" id="form-control-3">'+
    '<div class="col-md-10"><input class="form-control col-sm-12" type="number" placeholder="Enter Home Telephone Number"></div>'+    
    '<button type="button" id="remove-btn1" class="remove_btn"><i class="fas fa-minus"></i></button></div>');
});

$('.panel-body').on('click','#remove-btn1',function() {
    $(this).parent().remove();
});
/*hHome Telephone Number end*/


/*Mobile Telephone Number*/

$('#insert-btn4').click(function() {   
    $('.form-control-4:last').after('<div class="row form-area" id="form-control-4">'+
    '<div class="col-md-10"><input class="form-control col-sm-12" type="number" placeholder="Enter Mobile Telephone Number"></div>'+    
    '<button type="button" id="remove-btn1" class="remove_btn"><i class="fas fa-minus"></i></button></div>');
});

$('.panel-body').on('click','#remove-btn1',function() {
    $(this).parent().remove();
});
/*Mobile Telephone Number end*/

/*Work Telephone Number*/

$('#insert-btn5').click(function() {   
    $('.form-control-5:last').after('<div class="row form-area" id="form-control-5">'+
    '<div class="col-md-10"><input class="form-control col-sm-12" type="number" placeholder="Enter Work Telephone Number"></div>'+    
    '<button type="button" id="remove-btn1" class="remove_btn"><i class="fas fa-minus"></i></button></div>');
});

$('.panel-body').on('click','#remove-btn1',function() {
    $(this).parent().remove();
});
/*Work Telephone Number end*/

/*Home Mobile Number*/
$('#insert-btn6').click(function() {   
    $('.form-control-6:last').after('<div class="row form-area" id="form-control-6">'+
    '<div class="col-md-10"><input class="form-control col-sm-12" type="number" placeholder="Enter Home Mobile Number"></div>'+    
    '<button type="button" id="remove-btn1" class="remove_btn"><i class="fas fa-minus"></i></button></div>');
});

$('.panel-body').on('click','#remove-btn1',function() {
    $(this).parent().remove();
});
/*Home Mobile Number end*/


/*work fax Number*/
$('#insert-btn7').click(function() {   
    $('.form-control-7:last').after('<div class="row form-area" id="form-control-7">'+
    '<div class="col-md-10"><input class="form-control col-sm-12" type="number" placeholder="Enter work fax Number"></div>'+    
    '<button type="button" id="remove-btn1" class="remove_btn"><i class="fas fa-minus"></i></button></div>');
});

$('.panel-body').on('click','#remove-btn1',function() {
    $(this).parent().remove();
});
/*work fax Number end*/


/*Work Email Address*/

$('#insert-btn8').click(function() {   
    $('.form-control-8:last').after('<div class="row form-area" id="form-control-8">'+
    '<div class="col-md-10"><input class="form-control col-sm-12" type="email" placeholder="Work Email Address"></div>'+    
    '<button type="button" id="remove-btn1" class="remove_btn"><i class="fas fa-minus"></i></button></div>');
});

$('.panel-body').on('click','#remove-btn1',function() {
    $(this).parent().remove();
});

/*Work Email Address end*/

/*Alternate Address Change*/
$('#insert-btn9').click(function() {      
    $('.form-control-9:last').after('<div class="form-control-9"><hr/><div class="form-group row">'+
    '<div class="col-sm-4"><input class="form-control" type="number" placeholder="Enter Number"/></div>'+
    '<div class="col-sm-4"><input class="form-control" type="number" placeholder="Enter Number"/></div>'+
    '<div class="col-sm-4"><input class="form-control" type="number" placeholder="Enter Number"/></div>'+
 '</div>'+
 '<div class="form-group row">'+
    '<div class="col-sm-4"><input class="form-control" type="number" placeholder="Enter Number"/></div>'+
    '<div class="col-sm-4"><input class="form-control" type="number" placeholder="Enter Number"/></div>'+
    '<div class="col-sm-4"><input class="form-control" type="number" placeholder="Enter Number"/></div>'+
 '</div>'+    
    '<button type="button" class="remove-btn1"><i class="fas fa-minus"></i> Remove  Item</button></div>');
});
$('.panel-body').on('click','.remove-btn',function() {
 	$(this).parent().remove();
});
/*Alternate Address Change end*/

/*Replacement Card*/

$('#insert-btn10').click(function() { 
    $('.form-control-10:last').after('<div class="form-control-10"><hr/><div class="form-group row">'+
                              '<div class="col-sm-6"><label class="col-form-label">Card Type</label>'+                              
                              '<select class="form-control"><option>Select Card Type</option></select>'+
                              '</div><div class="col-sm-6">'+
                              '<label class="col-form-label">Card Number</label>'+                                    
                              '<input class="form-control" type="number" placeholder="Enter Number"/></div></div>'+
    '<button type="button" class="remove-btn1"><i class="fas fa-minus"></i> Remove  Item</button></div>');
});
$('.panel-body').on('click','.remove-btn',function() {
 	$(this).parent().remove();
});
/*Replacement Card end*/

/*Card Limit Change*/

$('#insert-btn11').click(function() { 
    $('.form-control-11:last').after('<div class="form-control-11"><hr/><h4>Limit Change (FOREX or Credit)</h4>'+
                           '<div class="row">'+
                              '<div class="col-sm-1"><label class="col-form-label">FX</label></div>'+
                              '<div class="col-sm-3"><label class="col-form-label">Card Number</label></div>'+
                              '<div class="col-sm-2"><label class="col-form-label">New Card Limit</label></div>'+
                             '<div class="col-sm-2"><label class="col-form-label">Temp Limit</label></div>'+
                              '<div class="col-sm-2"><label class="col-form-label">Start Date</label></div>'+
                              '<div class="col-sm-2"><label class="col-form-label">End Date</label></div>'+
                           '</div>'+
                           '<div class="row">'+
                              '<div class="col-sm-1 mt-2"><input class="form-control" type="checkbox"></div>'+
                              '<div class="col-sm-3"><input class="form-control" type="text"></div>'+
                              '<div class="col-sm-2"><input class="form-control" type="text"></div>'+
                              '<div class="col-sm-2 mt-2"><input class="form-control" type="checkbox"></div>'+
                              '<div class="col-sm-2"> <input class="form-control" type="date"></div>'+
                              '<div class="col-sm-2"> <input class="form-control" type="date"></div>'+
                           '</div>'+
    '<button type="button" class="remove-btn1"><i class="fas fa-minus"></i> Remove  Item</button></div>');
});
$('.panel-body').on('click','.remove-btn',function() {
 	$(this).parent().remove();
});
/*Card Limit Change end*/

/*Static Data*/
$('#insert-btn12').click(function() { 
    $('.form-control-12:last').after('<div class="form-control-12"><hr/>'+
                           '<div class="row">'+
                           '<div class="col-sm-2"><label>ID Type</label></div>'+
                           '<div class="col-sm-3"><label>ID Number</label></div>'+
                           '<div class="col-sm-3"><label>Country of Issue</label></div>'+
                           '<div class="col-sm-2"><label>Issue Date</label></div>'+
                           '<div class="col-sm-2"><label>Expiry Date</label></div>'+
                           '</div>'+
                           '<div class="row">'+
                           '<div class="col-sm-2">'+
                           '<select class="form-control"><option>--select --</option></select>'+
                           '</div>'+
                           '<div class="col-sm-3"><input type="text" class="form-control"></div>'+
                           '<div class="col-sm-3">'+
                           '<select class="form-control"><option>--select --</option></select>'+
                           '</div>'+
                           '<div class="col-sm-2"><input type="date" class="form-control"></div>'+
                           '<div class="col-sm-2"><input type="date" class="form-control"></div>'+
                           '</div>'+
                           '<button type="button" class="remove-btn1"><i class="fas fa-minus"></i> Remove  Item</button></div>');
});
$('.panel-body').on('click','.remove-btn',function() {
 	$(this).parent().remove();
});

/*Static Data end*/


/*Change Primary Deposit Account*/
$('#insert-btn13').click(function() { 
    $('.form-control-13:last').after('<div class="form-control-13"><hr/>'+
                           '<div class="row">'+
                           '<div class="col-sm-1"><label class="col-form-label">FX</label></div>'+
                           '<div class="col-sm-3"><label class="col-form-label">Card Number</label></div>'+
                           '<div class="col-sm-2"><label class="col-form-label">New Card Limit</label></div>'+
                           '<div class="col-sm-2"><label class="col-form-label">Temp Limit</label></div>'+
                           '<div class="col-sm-2"><label class="col-form-label">Start Date</label></div>'+
                           '<div class="col-sm-2"><label class="col-form-label">End date</label></div>'+
                           '</div>'+
                           '<div class="row">'+
                           '<div class="col-sm-1 mt-2"><input class="form-control" type="checkbox"></div>'+
                            '<div class="col-sm-3"><input class="form-control" type="text"></div>'+
                            '<div class="col-sm-2"><input class="form-control" type="text"></div>'+
                            '<div class="col-sm-2 mt-2"><input class="form-control" type="checkbox"></div>'+
                            '<div class="col-sm-2"> <input class="form-control" type="date"></div>'+
                            '<div class="col-sm-2"> <input class="form-control" type="date"></div>'+
                           '</div>'+
                           '<button type="button" class="remove-btn1"><i class="fas fa-minus"></i> Remove  Item</button></div>');
});
$('.panel-body').on('click','.remove-btn',function() {
 	$(this).parent().remove();
});
/*Change Primary Deposit Account end*/

/*Foreign Exchange Limit*/
$('#insert-btn14').click(function() { 
    $('.form-control-14:last').after('<div class="form-control-14"><hr/>'+
                           '<div class="row">'+
                           '<div class="col-sm-1"><label class="col-form-label">FX</label></div>'+
                           '<div class="col-sm-3"><label class="col-form-label">Card Number</label></div>'+
                           '<div class="col-sm-2"><label class="col-form-label">New Card Limit</label></div>'+
                           '<div class="col-sm-2"><label class="col-form-label">Temp Limit</label></div>'+
                           '<div class="col-sm-2"><label class="col-form-label">Start Date</label></div>'+
                           '<div class="col-sm-2"><label class="col-form-label">End date</label></div>'+
                           '</div>'+
                           '<div class="row">'+
                           '<div class="col-sm-1 mt-2"><input class="form-control" type="checkbox"></div>'+
                            '<div class="col-sm-3"><input class="form-control" type="text"></div>'+
                            '<div class="col-sm-2"><input class="form-control" type="text"></div>'+
                            '<div class="col-sm-2 mt-2"><input class="form-control" type="checkbox"></div>'+
                            '<div class="col-sm-2"> <input class="form-control" type="date"></div>'+
                            '<div class="col-sm-2"> <input class="form-control" type="date"></div>'+
                           '</div>'+
                           '<button type="button" class="remove-btn1"><i class="fas fa-minus"></i> Remove  Item</button></div>');
});
$('.panel-body').on('click','.remove-btn',function() {
 	$(this).parent().remove();
});
/*Foreign Exchange Limit end*/

/*Close Card*/
$('#insert-btn15').click(function() { 
    $('.form-control-15:last').after('<div class="form-control-15"><hr/>'+
                           '<div class="row">'+
                           '<div class="col-sm-1"><label class="col-form-label">FX</label></div>'+
                           '<div class="col-sm-3"><label class="col-form-label">Card Number</label></div>'+
                           '<div class="col-sm-2"><label class="col-form-label">New Card Limit</label></div>'+
                           '<div class="col-sm-2"><label class="col-form-label">Temp Limit</label></div>'+
                           '<div class="col-sm-2"><label class="col-form-label">Start Date</label></div>'+
                           '<div class="col-sm-2"><label class="col-form-label">End date</label></div>'+
                           '</div>'+
                           '<div class="row">'+
                           '<div class="col-sm-1 mt-2"><input class="form-control" type="checkbox"></div>'+
                            '<div class="col-sm-3"><input class="form-control" type="text"></div>'+
                            '<div class="col-sm-2"><input class="form-control" type="text"></div>'+
                            '<div class="col-sm-2 mt-2"><input class="form-control" type="checkbox"></div>'+
                            '<div class="col-sm-2"> <input class="form-control" type="date"></div>'+
                            '<div class="col-sm-2"> <input class="form-control" type="date"></div>'+
                           '</div>'+
                           '<button type="button" class="remove-btn1"><i class="fas fa-minus"></i> Remove  Item</button></div>');
});
$('.panel-body').on('click','.remove-btn',function() {
 	$(this).parent().remove();
});
/*Close Card end*/

/*Add Existing CIF to Account*/

$('#insert-btn16').click(function() { 
    $('.form-control-16:last').after('<div class="form-control-16"><hr/>'+
                           '<div class="row">'+
                           '<div class="col-sm-6"><label class="col-form-label">Other CIF Number(s)</label></div>'+
                           '<div class="col-sm-6"><label class="col-form-label">Relationship Code</label></div>'+
                           '</div>'+
                           '<div class="row">'+
                           '<div class="col-sm-6"><input class="form-control" type="text"></div>'+
                           '<div class="col-sm-6"><select class="form-control"><option>--Select--</option></select>'+
                           '</div>'+
                           '</div>'+
                           '<button type="button" class="remove-btn1"><i class="fas fa-minus"></i> Remove  Item</button></div>');
});
$('.panel-body').on('click','.remove-btn',function() {
 	$(this).parent().remove();
});
/*Add Existing CIF to Account end*/

/*Potential Activity (to be completed by Branch)*/
$('#insert-btn17').click(function() { 
    $('.form-control-17:last').after('<div class="form-control-17"><hr/>'+
                           '<div class="row">'+
                           '<div class="col-sm-3">'+
                           '<div class="row">'+
                           '<label class="col-sm-12 col-form-label"><strong>Account</strong></label>'+
                           '<label class="col-sm-12 col-form-label">Enter Account Number</label>'+
                           '<div class="col-sm-12">'+
                           '<select class="form-control"><option>--Select Country--</option><option>Australia</option><option>Bahrain</option><option>Canada</option><option>Denmark</option>'+
                           '</select>'+
                           '</div>'+
                           '</div>'+
                           '</div>'+
                           '<div class="col-sm-3">'+
                           '<div class="row">'+
                           '<label class="col-sm-12 col-form-label"><strong>Account Purpose</strong></label>'+
                           '<label class="col-sm-12 col-form-label">Enter Purpose of Account</label>'+
                           '<div class="col-sm-12">'+
                           '<textarea type="text"  rows="9"  class="form-control" placeholder="Enter Purpose of Account e.g saving"></textarea>'+
                           '</div>'+
                           '</div>'+
                           '</div>'+
                           '<div class="col-sm-3">'+
                           '<div class="row">'+
                           '<label class="col-sm-12 col-form-label"><strong>Monthly Transactions</strong></label>'+
                                 '<label class="col-sm-12 col-form-label">Debit</label>'+
                                 '<div class="col-sm-12">'+
                                 '<input type="text" class="form-control" placeholder="# Entries"/>'+
                                 '</div>'+
                                 '<div class="col-sm-12 mt-2">'+
                                 '<input type="text" class="form-control" placeholder="Value of Dabits"/>'+
                                 '</div>'+
                                 '<label class="col-sm-12 col-form-label">Credits</label>'+
                                 '<div class="col-sm-12">'+
                                 '<input type="text" class="form-control" placeholder="# Entries"/>'+
                                 '</div>'+
                                 '<div class="col-sm-12 mt-2">'+
                                 '<input type="text" class="form-control" placeholder="Value of Credits"/>'+
                                 '</div>'+
                                 '</div>'+
                                 '</div>'+
                                 '<div class="col-sm-3">'+
                                 '<div class="row">'+
                                 '<label class="col-sm-12 col-form-label"><strong>Source of Funds</strong></label>'+
                                 '<label class="col-sm-12 col-form-label">Enter Source of Funds e.g Salary</label>'+
                                 '<div class="col-sm-12">'+
                                 '<textarea type="text" rows="9" class="form-control" placeholder="Enter Purpose of Account e.g saving"></textarea>'+
                                 '</div>'+
                                 '</div>'+
                                 '</div>'+
                                 '</div>'+
                           '<button type="button" class="remove-btn1"><i class="fas fa-minus"></i> Remove  Item</button></div>');
});
$('.panel-body').on('click','.remove-btn',function() {
 	$(this).parent().remove();
});
/*Potential Activity (to be completed by Branch) end*/