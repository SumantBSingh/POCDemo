﻿using NHibernate;
using NHibernate.Cfg;
using System.Web;

namespace CrudPOCWithNhibernate.NhibernateConfig
{
    public class NhibernateHelper
    {
        public static ISession OpenSession()
        {
            var configuration = new Configuration();
            var configurationPath = HttpContext.Current.Server.MapPath(@"~\NhibernateConfig\hibernate.cfg.xml");
            configuration.Configure(configurationPath);

            #region Add XML mapping files
            var tableNameConfigurationFile = HttpContext.Current.Server.MapPath(@"~\Mappings\TableNames.hbm.xml");
            configuration.AddFile(tableNameConfigurationFile);
            var tableAConfigurationFile = HttpContext.Current.Server.MapPath(@"~\Mappings\TableA.hbm.xml");
            configuration.AddFile(tableAConfigurationFile);
            var tableBConfigurationFile = HttpContext.Current.Server.MapPath(@"~\Mappings\TableB.hbm.xml");
            configuration.AddFile(tableBConfigurationFile);
            var tableCConfigurationFile = HttpContext.Current.Server.MapPath(@"~\Mappings\TableC.hbm.xml");
            configuration.AddFile(tableCConfigurationFile);
            var tableDConfigurationFile = HttpContext.Current.Server.MapPath(@"~\Mappings\TableD.hbm.xml");
            configuration.AddFile(tableDConfigurationFile);
            #endregion

            ISessionFactory sessionFactory = configuration.BuildSessionFactory();
            return sessionFactory.OpenSession();
        }
    }
}