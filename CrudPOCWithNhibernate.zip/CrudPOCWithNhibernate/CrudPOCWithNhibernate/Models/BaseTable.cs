﻿using System;

namespace CrudPOCWithNhibernate.Models
{
    public class BaseTable
    {
        public virtual int Status { get; set; }
        public virtual DateTime CreateDateTime { get; set; }
        public virtual DateTime UpdateDateTime { get; set; }
    }
}