﻿using System.ComponentModel.DataAnnotations;

namespace CrudPOCWithNhibernate.Models
{
    public class TableB : BaseTable
    {
        public virtual long Id { get; set; }
        [Required]
        public virtual string FirstName { get; set; }
        [Required]
        public virtual string LastName { get; set; }
        [Required]
        public virtual string Designation { get; set; }
    }
}