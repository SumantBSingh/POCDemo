﻿namespace CrudPOCWithNhibernate.Models
{
    public class TableNames : BaseTable
    {
        public virtual int Id { get; set; }
        public virtual string TableName { get; set; }
    }
}