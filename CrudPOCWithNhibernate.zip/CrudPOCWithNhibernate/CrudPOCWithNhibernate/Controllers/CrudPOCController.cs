﻿using CrudPOCWithNhibernate.Models;
using CrudPOCWithNhibernate.NhibernateConfig;
using NHibernate.Criterion;
using System;
using System.Collections.Generic;
using System.EnterpriseServices;
using System.Linq;
using System.ServiceModel.Channels;
using System.Web;
using System.Web.Mvc;

namespace CrudPOCWithNhibernate.Controllers
{
    public class CrudPOCController : Controller
    {
        // GET: CrudPOC
        public ActionResult Index()
        {
            ViewBag.GetTables = GetTableName();

            return View();

        }

        [ChildActionOnly]
        public ActionResult HtmlTableWebGrid()
        {
            using (var session = NhibernateHelper.OpenSession())
            {
                ViewBag.SelectedTableId = 1;
                return PartialView("_TableAWebGrid", session.Query<TableA>().ToList().Where(x => x.Status == 1));
            }

        }

        [ChildActionOnly]
        [HttpPost]
        public ActionResult HtmlTableWebGrid(FormCollection form)
        {
            var selectedValue = form["hdndbTables"].ToString();
            ViewBag.SelectedTableId = form["dbTables"].ToString();

            using (var session = NhibernateHelper.OpenSession())
            {
                switch (selectedValue)
                {
                    case "TableA":
                        return PartialView("_TableAWebGrid", session.Query<TableA>().ToList().Where(x => x.Status == 1));
                    case "TableB":
                        return PartialView("_TableBWebGrid", session.Query<TableB>().ToList().Where(x => x.Status == 1));
                    case "TableC":
                        return PartialView("_TableCWebGrid", session.Query<TableC>().ToList().Where(x => x.Status == 1));
                    case "TableD":
                        return PartialView("_TableDWebGrid", session.Query<TableD>().ToList().Where(x => x.Status == 1));
                    default:
                        return null;
                }
            }

        }

        [HttpPost]
        public ActionResult Index(FormCollection form)
        {
            var selectedValue = form["hdndbTables"].ToString();
            var masterData = GetTableName();
            foreach (var item in masterData)
            {
                if (item.Text == selectedValue)
                {
                    item.Selected = true;
                    break;
                }
            }
            ViewBag.GetTables = masterData;
            return View();
        }

        private List<SelectListItem> GetTableName()
        {
            using (var session = NhibernateHelper.OpenSession())
            {
                var result = session.Query<TableNames>("TableNames").ToList();
                var items = new List<SelectListItem>();
                foreach (var table in result)
                {
                    items.Add(new SelectListItem()
                    {
                        Text = table.TableName,
                        Value = table.Id.ToString(),
                        // Put all sorts of business logic in here
                        Selected = table.Id == 1
                    });
                }
                return items;
            }
        }

        public ActionResult Create()
        {
            ViewBag.GetTables = GetTableName();
            return View();
        }

        [HttpPost]
        public ActionResult Create(TableA tableA, string dbTables)
        {
            try
            {
                using (var session = NhibernateHelper.OpenSession())
                {
                    using (var transaction = session.BeginTransaction())
                    {
                        switch (dbTables)
                        {
                            case "1":
                                tableA.Status = 1;
                                tableA.CreateDateTime = DateTime.Now;
                                tableA.UpdateDateTime = DateTime.Now;
                                session.Save(tableA);

                                break;
                            case "2":
                                TableB tableB = new TableB
                                {
                                    FirstName = tableA.FirstName,
                                    LastName = tableA.LastName,
                                    Designation = tableA.Designation,
                                    Status = 1,
                                    CreateDateTime = DateTime.Now,
                                    UpdateDateTime = DateTime.Now
                                };
                                session.Save(tableB);

                                break;
                            case "3":
                                TableC tablec = new TableC
                                {
                                    FirstName = tableA.FirstName,
                                    LastName = tableA.LastName,
                                    Designation = tableA.Designation,
                                    Status = 1,
                                    CreateDateTime = DateTime.Now,
                                    UpdateDateTime = DateTime.Now
                                };
                                session.Save(tablec);

                                break;
                            case "4":

                                TableD tableD = new TableD
                                {
                                    FirstName = tableA.FirstName,
                                    LastName = tableA.LastName,
                                    Designation = tableA.Designation,
                                    Status = 1,
                                    CreateDateTime = DateTime.Now,
                                    UpdateDateTime = DateTime.Now
                                };
                                session.Save(tableD);

                                break;
                            default:
                                return null;
                        }
                        transaction.Commit();
                    }
                }
                return RedirectToAction("Index");

            }
            catch (Exception)
            {
                return View();
            }
        }

        public ActionResult Edit(long id, int tblId)
        {
            using (var session = NhibernateHelper.OpenSession())
            {
                switch (tblId)
                {
                    case 1:
                        return PartialView("_TableAEditPopup", session.Get<TableA>(id));
                    case 2:
                        return PartialView("_TableBEditPopup", session.Get<TableB>(id));
                    case 3:
                        return PartialView("_TableCEditPopup", session.Get<TableC>(id));
                    case 4:
                        return PartialView("_TableDEditPopup", session.Get<TableD>(id));
                    default:
                        return null;
                }
            }
        }

        [HttpPost]
        public JsonResult UpdateTableA(TableA tableA)
        {
            try
            {
                using (var session = NhibernateHelper.OpenSession())
                {
                    var tableAUpdate = session.Get<TableA>(tableA.Id);

                    tableAUpdate.Designation = tableA.Designation;
                    tableAUpdate.FirstName = tableA.FirstName;
                    tableAUpdate.LastName = tableA.LastName;
                    tableAUpdate.Status = 1;
                    tableAUpdate.CreateDateTime = DateTime.Now;
                    tableAUpdate.UpdateDateTime = DateTime.Now;
                    using (var transaction = session.BeginTransaction())
                    {
                        session.Save(tableAUpdate);
                        transaction.Commit();
                    }
                }
                return Json("Update Successful", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("Failed to Update", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult UpdateTableB(TableB tableB)
        {
            try
            {
                using (var session = NhibernateHelper.OpenSession())
                {
                    var tableBUpdate = session.Get<TableB>(tableB.Id);

                    tableBUpdate.Designation = tableB.Designation;
                    tableBUpdate.FirstName = tableB.FirstName;
                    tableBUpdate.LastName = tableB.LastName;
                    tableBUpdate.Status = 1;
                    tableBUpdate.CreateDateTime = DateTime.Now;
                    tableBUpdate.UpdateDateTime = DateTime.Now;
                    using (var transaction = session.BeginTransaction())
                    {
                        session.Save(tableBUpdate);
                        transaction.Commit();
                    }
                }
                return Json("Update Successful", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("Failed to Update", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult UpdateTableC(TableC tableC)
        {
            try
            {
                using (var session = NhibernateHelper.OpenSession())
                {
                    var tableCUpdate = session.Get<TableC>(tableC.Id);

                    tableCUpdate.Designation = tableC.Designation;
                    tableCUpdate.FirstName = tableC.FirstName;
                    tableCUpdate.LastName = tableC.LastName;
                    tableCUpdate.Status = 1;
                    tableCUpdate.CreateDateTime = DateTime.Now;
                    tableCUpdate.UpdateDateTime = DateTime.Now;
                    using (var transaction = session.BeginTransaction())
                    {
                        session.Save(tableCUpdate);
                        transaction.Commit();
                    }
                }
                return Json("Update Successful", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("Failed to Update", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult UpdateTableD(TableD tableD)
        {
            try
            {
                using (var session = NhibernateHelper.OpenSession())
                {
                    var tableDUpdate = session.Get<TableD>(tableD.Id);

                    tableDUpdate.Designation = tableD.Designation;
                    tableDUpdate.FirstName = tableD.FirstName;
                    tableDUpdate.LastName = tableD.LastName;
                    tableDUpdate.Status = 1;
                    tableDUpdate.CreateDateTime = DateTime.Now;
                    tableDUpdate.UpdateDateTime = DateTime.Now;
                    using (var transaction = session.BeginTransaction())
                    {
                        session.Save(tableDUpdate);
                        transaction.Commit();
                    }
                }
                return Json("Update Successful", JsonRequestBehavior.AllowGet);
            }
            catch
            {
                return Json("Failed to Update", JsonRequestBehavior.AllowGet);
            }
        }

        [HttpPost]
        public JsonResult Delete(long id, int tableId)
        {
            try
            {
                using (var session = NhibernateHelper.OpenSession())
                {
                    using (var transaction = session.BeginTransaction())
                    {
                        switch (tableId)
                        {
                            case 1:
                                var tableAUpdate = session.Get<TableA>(id);
                                tableAUpdate.Status = 0;
                                session.Save(tableAUpdate);
                                break;
                            case 2:
                                var tableBUpdate = session.Get<TableB>(id);
                                tableBUpdate.Status = 0;
                                session.Save(tableBUpdate);
                                break;
                            case 3:
                                var tableCUpdate = session.Get<TableC>(id);
                                tableCUpdate.Status = 0;
                                session.Save(tableCUpdate);
                                break;
                            case 4:
                                var tableDUpdate = session.Get<TableD>(id);
                                tableDUpdate.Status = 0;
                                session.Save(tableDUpdate);
                                break;
                            default:
                                return null;
                        }

                        //session.Delete(string.Format("from {0} p where p.Id = {1}", tableName, id));
                        transaction.Commit();
                    }
                }
                return Json("Deletion Successful", JsonRequestBehavior.AllowGet);
            }
            catch (Exception)
            {
                return Json("Failed to delete", JsonRequestBehavior.AllowGet);
            }
        }
    }
}